﻿using Test.Extensions.ViewModel;
using Microsoft.AspNetCore.Mvc;

namespace Test.Extensions.Controllers
{
    [Route("api/filtering")]
    [ApiController]
    public class FilteringController : Controller
    {
        private static List<string> _cache = new();

        [HttpGet]
        public IEnumerable<FilteringModel.Item> Get()
        {
            var selected = _cache;

            var all = GetAllFields();

            return all.Where(x => selected.Contains(x.FieldId)).OrderBy(x => selected.IndexOf(x.FieldId)).ToList();
        }

        [Route("setting")]
        [HttpGet]
        public FilteringModel GetSetting()
        {
            var selected = _cache;
            var all = GetAllFields();

            return new FilteringModel
            {
                Filters = all,
                Items = all.Where(x => selected.Contains(x.FieldId)).OrderBy(x => selected.IndexOf(x.FieldId)).Select(x => x.FieldId).ToList(),
            };
        }

        [Route("setting")]
        [HttpPost]
        public IActionResult SaveSetting([FromBody] FilteringModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var selected = model.Items.ToList();
            _cache = selected;
            model = GetSetting();

            model.Message = "Updated";
            return Ok(model);
        }

        private List<FilteringModel.Item> GetAllFields()
        {
            return Enumerable.Range(1, 50)
                .Select(i => new FilteringModel.Item { FieldId = "field_" + i, Title = "field " + i, GroupName = "Group " + (i % 10) })
                .ToList();
        }
    }
}
