﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using Microsoft.Net.Http.Headers;

// Microsoft best practice is to place the extensions to the IApplicationBuilder
// in the same namespace to easy find them when using intellisense without extra
// usings.
namespace Microsoft.AspNetCore.Builder
{
    public static class ResponceCacheBuilderExtensions
    {
        /// <summary>
        /// Enable the ability to disable automatic caching for responses where the cache-control header is missing.
        /// </summary>
        /// <param name="app">The <see cref="IApplicationBuilder"/>.</param>
        /// <returns>The <see cref="IApplicationBuilder"/>.</returns>
        public static IApplicationBuilder UseDynamicResponseCaching(this IApplicationBuilder app)
        {
            app.Use((httpContext, next) =>
            {
                httpContext.Response.OnStarting(EnsureCacheHeaderExists, httpContext);
                return next();
            });
            return app;
        }

        public static readonly StringValues NoCacheString = new(new[] { CacheControlHeaderValue.NoStoreString, CacheControlHeaderValue.NoCacheString });

        private static Task EnsureCacheHeaderExists(object state)
        {
            if (state is HttpContext httpContext)
            {
                var cacheControlHeader = httpContext.Response.Headers[HeaderNames.CacheControl];
                if (cacheControlHeader.Count == 0)
                {
                    httpContext.Response.Headers[HeaderNames.CacheControl] = NoCacheString;
                }
            }
            return Task.CompletedTask;
        }
    }
}
