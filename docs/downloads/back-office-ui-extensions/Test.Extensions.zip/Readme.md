External test extensions
===

This project contains external test extension for the Litium administration.

1. Build the Angular project with `yarn install && yarn build` in the `frontend` folder.
2. Start the _test extesnsions_ website with either `dotnet run` or inside your editor from the `backend` folder.
3. Register the extension with your litium installation, see below.

## Register with Litium

This can be installed with `POST` the below content into `Litium/api/extension-management/extensions`.
Adjusting of URLs in the content may be needed to match your installation.

```
{
    "id": "test",
    "name": "My extension",
    "description": "My extension from external source",
    "targets": [
        {
            "target": "common.angular.module",
            "name": "TestExtensions",
            "url": "https://test-extensions.localtest.me:35863/dist"
        },
        {
            "target": "common.api.proxy",
            "name": "TestExtensions",
            "url": "https://test-extensions.localtest.me:35863/"
        },
        {
            "target": "settings.menu.group",
            "name": "t:extensions.test.title",
            "id": "my_group"
        },
        {
            "target": "settings.menu.item",
            "name": "t:extensions.test.setting.filtering",
            "ref_id": "my_group",
            "url": "TestExtensions/filtering"
        },
        {
            "target": "customers.menu.item",
            "name": "t:extensions.test.panel.name",
            "component": "TestExtensions#SampleAngularPanelComponent",
            "setting": "eyJ0aXRsZSI6InZhbHVlIn0="
        },
        {
            "target": "media.menu.item",
            "name": "t:extensions.test.panel.name",
            "component": "TestExtensions#SampleAngularPanelComponent",
            "setting": "eyJ0aXRsZSI6InZhbHVlIn0="
        },
        {
            "target": "products.menu.item",
            "name": "t:extensions.test.panel.name",
            "component": "TestExtensions#SampleAngularPanelComponent",
            "setting": "eyJ0aXRsZSI6InZhbHVlIn0="
        },
        {
            "target": "sales.menu.item",
            "name": "t:extensions.test.panel.name",
            "component": "TestExtensions#SampleAngularPanelComponent",
            "setting": "eyJ0aXRsZSI6InZhbHVlIn0="
        },
        {
            "target": "websites.menu.item",
            "name": "t:extensions.test.panel.name",
            "component": "TestExtensions#SampleAngularPanelComponent",
            "setting": "eyJ0aXRsZSI6InZhbHVlIn0="
        }
    ],
    "type": "ui",
    "texts": {
        "en": {
            "extensions.test.title": "Test extensions",
            "extensions.test.setting.indexing": "Product grouping",
            "extensions.test.setting.filtering": "Product filtering",
            "extensions.test.setting.search": "Search indexing",
            "extensions.test.settings.searchindexing.headline": "Search indexing settings",
            "extensions.test.settings.headline": "Settings",
            "extensions.test.settings.index.template.headlines": "Variants are grouped in the Accelerator based on the following field",
            "extensions.test.settings.index.template.null.label": "Do not group",
            "extensions.test.fieldtemplate.productarea.productwithonevariant.name": "Product with only one variant",
            "extensions.test.fieldtemplate.productarea.productwithvariants.name": "Product with variants",
            "extensions.test.fieldtemplate.productarea.productwithvariantslist.name": "Product with variants shown in a list",
            "extensions.test.filterfield.headline": "Fields that are possible to use as filters on the public site",
            "extensions.test.filtering.headline": "Product filter",
            "extensions.test.filterfield.field": "Field",
            "extensions.test.settings.searchindexing.template.general.templates.headline": "Searching in Accelerator is based on selected fields. If the template doesn't have any selected fields then the search is based on all fields.",
            "extensions.test.settings.searchindexing.template.template": "Template",
            "extensions.test.settings.searchindexing.template.fields": "Fields",
            "extensions.test.settings.searchindexing.template.selectedfields": "Selected fields",
            "extensions.test.settings.searchindexing.template.product.templates.headline": "Product templates",
            "extensions.test.settings.searchindexing.template.category.templates.headline": "Category templates",
            "extensions.test.settings.searchindexing.template.page.templates.headline": "Page templates",
            "extensions.test.settings.searchindexing.template.block.templates.headline": "Block templates",
            "extensions.test.panel.name": "Panel from extension"
        },
        "sv": {
            "extensions.test.title": "Test extensions",
            "extensions.test.setting.indexing": "Produktgruppering",
            "extensions.test.setting.filtering": "Produktfiltrering",
            "extensions.test.setting.search": "S�kindexering",
            "extensions.test.settings.searchindexing.headline": "Inst�llningar f�r s�kindex",
            "extensions.test.settings.headline": "Inst�llningar",
            "extensions.test.settings.index.template.headlines": "Varianter listas efter f�ljande f�lt",
            "extensions.test.filterfield.headline": "F�lt som kan anv�ndas vid produktfiltrering p� publika siten.",
            "extensions.test.filtering.headline": "Produktfilter",
            "extensions.test.filterfield.field": "F�lt",
            "extensions.test.settings.searchindexing.template.general.templates.headline": "S�kning i Acceleratorn baseras p� valda f�lt. Om mallen inte har n�gra valt f�lt baseras s�kningen p� alla f�lt.",
            "extensions.test.settings.searchindexing.template.template": "Mall",
            "extensions.test.settings.searchindexing.template.fields": "F�lt",
            "extensions.test.settings.searchindexing.template.selectedfields": "Valda f�lt",
            "extensions.test.settings.searchindexing.template.product.templates.headline": "Produktmallar",
            "extensions.test.settings.searchindexing.template.category.templates.headline": "Kategorimallar",
            "extensions.test.settings.searchindexing.template.page.templates.headline": "Sidmallar",
            "extensions.test.settings.searchindexing.template.block.templates.headline": "Blockmallar",
            "extensions.test.panel.name": "Panel fr�n extension"
       }
    }
}
```
