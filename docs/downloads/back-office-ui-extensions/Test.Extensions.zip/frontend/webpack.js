const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");
const angularCorePkJson = require('@angular/core/package.json');
const angularCommonPkJson = require('@angular/common/package.json');
const angularRouterPkJson = require('@angular/router/package.json');
const angularFormPkJson = require('@angular/forms/package.json');
const angularReduxPkJson = require('@angular-redux3/store/package.json');
const ngxTranslatePkJson = require('@ngx-translate/core/package.json');

module.exports = {
    optimization: {
        runtimeChunk: false,
    },
    entry: {
        // The file for the remoteConfig module need to be included as entry file with the same name as
        // the extension name in the ModuleFederationPlugin:name property.
        //
        // When this is added the module is included in remoteEntry.js file directly and methods can be 
        // invoked without additional files loaded from extension path.
        TestExtensions: "./src/remote-config.ts"
    },
    plugins: [
        new ModuleFederationPlugin({
            name: 'TestExtensions',
            filename: 'remoteEntry.js',
            exposes: {
                remoteConfig: './src/remote-config.ts',
                TestExtensions: './src/extensions.ts',
                SampleAngularPanelComponent: "./src/components/sample-angular-panel/sample-angular-panel.component.ts",
            },
            shared: {
                '@angular/core': {
                    eager: false,
                    singleton: true,
                    requiredVersion: angularCorePkJson.version,
                },
                '@angular/common': {
                    eager: false,
                    singleton: true,
                    requiredVersion: angularCommonPkJson.version,
                },
                '@angular/router': {
                    eager: false,
                    singleton: true,
                    requiredVersion: angularRouterPkJson.version,
                },
                '@angular/forms': {
                    eager: false,
                    singleton: true,
                    requiredVersion: angularFormPkJson.version,
                },
                '@angular/common/http': {
                    eager: false,
                    singleton: true,
                    requiredVersion: angularCommonPkJson.version,
                },
                '@angular-redux3/store': {
                    eager: false,
                    singleton: true,
                    requiredVersion: angularReduxPkJson.version,
                },
                '@ngx-translate/core': {
                    eager: false,
                    singleton: true,
                    requiredVersion: ngxTranslatePkJson.version,
                },
                'litium-ui': { eager: false, singleton: true },
            },
        }),
    ],
};
