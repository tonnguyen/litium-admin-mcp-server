import { Component, ChangeDetectionStrategy } from '@angular/core';
@Component({
    selector: 'app-sample-angular-panel',
    templateUrl: './sample-angular-panel.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SampleAngularPanelComponent {
    settings: any;
}