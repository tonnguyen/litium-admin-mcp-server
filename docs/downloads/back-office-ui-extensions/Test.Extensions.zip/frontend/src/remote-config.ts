﻿import { RemoteConfig } from 'litium-ui';

declare var __webpack_public_path__: string;
declare var window: any;

export function configure(config: RemoteConfig) {
    // set the public path to load module from
    __webpack_public_path__ = config.remotePath;
}

function getExtensionConfig(): RemoteConfig {
    return window.litiumExtensionConfig['TestExtensions'] ?? {};
}

export function remoteApiPath() {
    const extensionConfig = getExtensionConfig();
    return extensionConfig.remoteApiPath || '';
}
