﻿using Litium.GDPR;
using Litium.Runtime.DependencyInjection;
using System;
using System.Collections.Generic;

namespace Litium.Docs.Samples.Gdpr
{

    [Service(Name = nameof(CustomData), FallbackService = true)]
    public class GdprCustomDataRemover : EntityRemoverBase<CustomData>
    {
        public override void Delete(CustomData dataRecord)
        {
            //TODO: remove the customer data
        }

        protected override void EnsureDeleted( IEnumerable<Guid> systemIds)
        {
           
        }
    }
}
