﻿using JetBrains.Annotations;
using Litium.Customers;
using Litium.GDPR;
using Litium.Runtime.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Litium.Docs.Samples.Gdpr
{

    public class ErpCustomerData
    {
        public string ErpId { get; set; }

        public string Secret { get; set; }
    }
}
