﻿using JetBrains.Annotations;
using Litium.GDPR;
using Litium.Runtime.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Litium.Docs.Samples.Gdpr
{

    public class GdprCustomDataSearcher : IDataSearcher
    {
        public IEnumerable<IDataRecord> Search(IDataIdentity identity)
        {
            //TODO: search for erp data.
            var erpCustomer = new ErpCustomerData { ErpId = "1234567", Secret = "Hello world!" };
            return new List<CustomData>() { new CustomData(erpCustomer) };
        }
    }
}
