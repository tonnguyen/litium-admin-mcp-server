﻿using JetBrains.Annotations;
using Litium.GDPR;
using Litium.Runtime.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Litium.Docs.Samples.Gdpr
{

    [Service(Name = nameof(CustomData), FallbackService = true)]
    public class GdprCustomDataExport : NodeFactoryBase<CustomData>
    {
        protected override object ExtractData(CustomData arg)
        {
            return arg?.Data;
        }

        protected override string ExtractId(CustomData arg)
        {
            return arg?.Data?.ErpId;
        }

        protected override ISet<PropertyInfo> GetExcludedProperties()
        {
            return new HashSet<PropertyInfo>
            {
                 typeof(ErpCustomerData).GetProperty(nameof(ErpCustomerData.Secret))
            };
        }
    }
}
