﻿using Litium.GDPR;
using Litium.Runtime.DependencyInjection;

namespace Litium.Docs.Samples.Gdpr
{

    [ServiceDecorator(typeof(INodeFactory), Name = nameof(PersonData))]
    public class CustomPersonNodeBuilder : INodeFactory
    {
        private readonly INodeFactory _nodeFactory;
        public CustomPersonNodeBuilder(INodeFactory nodeFactory)
        {
            _nodeFactory = nodeFactory;
        }

        public ExportNode Create(IDataRecord dataRecord)
        {
            var defaultImplementation = _nodeFactory.Create(dataRecord);

            //TODO: modify the defualt implementation.
            return defaultImplementation;
        }
    }
}
